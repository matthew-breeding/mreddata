from .datatools import options, mreddata, plot_options

#define common symbols used in plot titles/axes/legends etc.
mu = '\u03bc'
deg = '\u03B1'
