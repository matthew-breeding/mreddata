from ._optionsParser import options
#options = resetOptions()
def printOptions():
	print(options)
